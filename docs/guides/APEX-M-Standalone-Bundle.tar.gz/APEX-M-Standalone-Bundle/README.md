# APEX-M · Standalone Bundle

This tarball contains the minimum slice of the APEX monorepo needed to
run APEX-M against in-process mock implementations on a developer laptop.

## What's here

```
apex-m/                          # APEX-M source + Bicep IaC
packages/apex-core/              # APEX-Core protocol definitions (workspace dep)
docs/guides/APEX-M-Local-Setup/  # Quickstart README + requirements.txt + .env.example
```

## Quickstart

```bash
# 1) Extract
tar -xzf APEX-M-Standalone-Bundle.tar.gz
cd APEX-M-Standalone-Bundle

# 2) Read the full setup guide
cat docs/guides/APEX-M-Local-Setup/README.md

# 3) Run the bash quickstart (uv-or-pip + mock agent)
./docs/guides/APEX-M-Local-Setup/run-local-mock.sh

# Or on Windows
.\docs\guides\APEX-M-Local-Setup\run-local-mock.ps1
```

## What you can NOT do with this bundle alone

- Run sibling variants (APEX-G, APEX-A) — not included
- Run the wizard's render endpoint — apps/deploy-wizard not included
- Run any other practice's MCP tools (RC, HLS, ICE, TH, AXLE) — not included
- Deploy to a real Azure tenant — requires the full repo + Bicep blueprints

For any of the above, clone the full repo from
https://github.com/Deloitte-US-Consulting/APEX

## Independence posture

Laptop substrate with `APEX_FORCE_MOCK=true` touches **no client cloud
subscription** and bills **no Microsoft / Google / AWS API call**.
Independence-clean by construction per `docs/apex-core/Independence-Posture.md`
in the full repo.

---

**Bundle version:** 1.0 · **Generated:** 2026-05-29
